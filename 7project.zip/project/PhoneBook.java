package project;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.nio.Buffer;
import java.util.Scanner;
import java.util.Vector;

public class PhoneBook{	
	
	public static void main(String[] ars) {
		
		Vector<Person> v = new Vector<Person>();
		Scanner sc = new Scanner(System.in);
		
		BufferedReader br = null;
		BufferedWriter bw = null;
		//File f = new File("‪C:\\Temp\\phonebook.txt");
		File f = new File("C:\\Temp\\phonebook.txt");  // ✅ 직접 타이핑
		
		if(f.exists()) {
			try {
			br = new BufferedReader(new FileReader(f));
			
			while(true) {
				String l = br.readLine(); //한줄 읽어오기
				if(l != null) {
					String t [] = l.split(" "); //나누기
					Person p = new Person(t[0],t[1],t[2]);
					v.add(p);
				}else {
					break;
				}
			}
			}catch(Exception e){
				e.printStackTrace();
			}
		}
		
		
		while(true) {
		System.out.println("메뉴 : 입력(1),삭제(2),검색(3),전체리스트(4),저장(5),종료(6)");
		int input = sc.nextInt();

		if(input ==1 ) {
			System.out.println("이름 전화번호 이메일을 입력하세요");
			
			Person p = new Person(); //Person따로 갖고옴
			System.out.println("이름입력");
			p.name = sc.next();
			p.phone = sc.next();
			p.email = sc.next();
			System.out.println("전하번호부에 입력했습니다.");

			// 벡터에 넣어줌
			v.add(p);
			
		}else if(input==2) {
			System.out.println("삭제할 사람의 이름을 입력하세요");
			String n = sc.next();
			for(int i=0; i<v.size(); i++) {
				Person p = v.get(i); //Person 에서 따로 get 해서 가져와야함
				if(n.equals(p.name)) {
					v.remove(i);							
					System.out.println(n+"을 전화번호부에서 삭제했습니다.");
					break;
				}
			}
		}else if(input==3) {
			System.out.println("검색할 이름");
			String n = sc.next();
			for(int i=0; i<v.size(); i++) {
				Person p = v.get(i); //Person 에서 따로 get 해서 가져와야함
				if(n.equals(p.name)) {
					System.out.println(p+"을 전화번호부에서 찾습니다.");
					break;
				}
			}
		}else if(input==4) {
			for(int i=0; i<v.size(); i++) {
				Person p = v.get(i);
				System.out.println(p.name+" " +p.phone + " " +p.email+ "");
			}
		}else if(input==5) {
			try {
			bw = new BufferedWriter(new FileWriter(f));
			for(int i=0; i<v.size(); i++) {
				Person p = v.get(i);
				bw.write(p.name+" " +p.phone + " " +p.email+ "\r");
			}
			bw.close();
			System.out.println("전화번호부에 저장완료");
			}catch(IOException e) {
				e.printStackTrace();
			}
		
		}else if(input==6) {
			System.out.println("전화번호부를 종료합니다");
			break;
			}
		}
	}
}

package project;

public class Person{
	String name;
	String phone;
	String email;

	public Person() {
		
	}
	
	public Person(String name, String phone , String email) {
		this.name=name;
		this.phone = phone;
		this.email = email;
	}
}
package zombieGame;

import java.util.*;
import java.awt.*;
import javax.swing.*;
import javax.swing.ImageIcon;

public class GraphicZombie  {
	final int MOVE_STEP = 5;
	final int MAX_X = 500;
	final int MAX_Y = 300;
	
	int x;
	int y;
	int imgWidth =20; //캐릭터 길이
	int imgHeight = 20; //캐릭터 넒이
	int dir;
	Random r = new Random();
	boolean toggle;  // 초기값은 false
	boolean status = false;
	
	ImageIcon batImgIcon[] = new ImageIcon[2];
	Image img[] = new Image[2];
	
	public GraphicZombie(int x, int y) {
		this.x = x; //받는값 만큼 위치 전하기
		this.y = y;
	
		for(int i=0; i<2; i++) {
			batImgIcon[i] = new ImageIcon("img/enemy"+(i+1)+".png");
			img[i] = batImgIcon[i].getImage();
		}
	}
	public void moveLeft() {
		x = x - MOVE_STEP;
		if(x < 0) x = 0;
	}
	
	// �� 
	public void moveRight() {
		x = x + MOVE_STEP;
		if(x > MAX_X - imgWidth) x = MAX_X - imgWidth;
	}	
	
	
	public void randomMove() {
		dir = r.nextInt(3); //0 1 2
		if(dir ==0);
			
		else if(dir==1) 
			moveLeft(); //메소드 실행
		else if(dir==2) 
			moveRight();
			toggle = !toggle;
		
	}
	
	public void paint(Graphics g) {
		if(toggle) g.drawImage(img[0] , x, y ,null);
		else g.drawImage(img[1], x,y,null);
	}
	
	
    public void checkCrash(int ex, int ey) {
        if ((x <= ex) && (ex <= (x + 20))) {
            if((y <= ey) && ( ey <= (y + imgHeight))) {
                status = true;
            }
        }       
        else if ((x <= ex + imgWidth) && (ex + imgWidth <= (x + imgWidth))) {
            if((y <= ey) && ( ey <= (y + imgHeight))) {
                status = true;
            }
        }
        else if ((x <= ex) && (ex <= (x + imgWidth))) {
            if((y <= ey + imgHeight) && ( ey + imgHeight <= (y + imgHeight))) {
                status = true;
            }
        }       
        else if ((x <= ex + imgWidth) && (ex + imgWidth <= (x + imgWidth))) {
            if((y <= ey + imgHeight) && ( ey + imgHeight <= (y + imgHeight))) {
                status = true;
            }
        }   
    }
}

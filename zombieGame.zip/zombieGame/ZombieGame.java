//연결된 파일 GraphicZombie.java
package zombieGame;

import javax.swing.*;

import java.awt.*;
import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;
import java.awt.event.MouseEvent;
import java.awt.event.MouseMotionListener;


public class ZombieGame extends JFrame {
	private GamePanel my = new GamePanel();
	
	
	ImageIcon heroicon1 = new ImageIcon("img/hero01.png");		
	Image righthero = heroicon1.getImage();
	ImageIcon heroicon2 = new ImageIcon("img/hero04.png");		
	Image lefthero = heroicon2.getImage();
	ImageIcon heroicon3 = new ImageIcon("img/hero03.png");		
	Image jumphero = heroicon3.getImage();
	
	int dir =0;
	int x = 0;
	int y = 170;
	boolean gameover;
	boolean zombieStatus1;
	boolean zombieStatus2;


	
		public ZombieGame() {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		this.setContentPane(my); // 객체 만들어주기
		setSize(500,300); //사이즈
		setVisible(true);
		my.setFocusable(true);
		my.requestFocus(true);
	}		
		
	class GamePanel extends JPanel implements KeyListener,Runnable {
		
		GraphicZombie zombie1 = new GraphicZombie(150, 170); //좀비객체
		GraphicZombie zombie2 = new GraphicZombie(300, 170); //좀비객체
		GraphicHero hero = new GraphicHero(0, 170); //히어로 객체
		
		
		public void paintComponent(Graphics g) {
			super.paintComponent(g);
			g.setColor(Color.black);
			g.fillRect(0,0,getWidth(),getHeight());
			g.setColor(Color.orange);
			g.fillRect(0,200,getWidth(),getHeight());
			
			if(gameover == true) {
				g.drawString("목적지에 도달했습니다. 게임종료",200,150);
			}
			if(zombie1.status || zombie2.status ) {
				g.drawString("좀비에게 잡혔습니다.",200,150);
			}

			
			hero.paint(g);
			zombie1.paint(g);
			zombie2.paint(g);
			//if(dir==0) g.drawImage(righthero,x,y,this );
			//else if(dir==1)g.drawImage(lefthero,x,y,this );


		}
		
		public GamePanel() { //기능추가
			hero.dir = 1;
			this.addKeyListener(this);
			
			new Thread(this).start();
		}
		
		@Override
		public void run() {
			while(true) {
				
				gameover = hero.heroMove();
				if(gameover == true) {
					repaint();
					break;
				}

	
				//좀비 움직이기
				zombie1.randomMove();
				zombie2.randomMove();
				
				//좀비 충돌
				zombie1.checkCrash(hero.x, hero.y);
				zombie2.checkCrash(hero.x, hero.y); //히어로랑 부딪혀야함
				
				
	            // 충돌 상태 확인 후 충돌 시 반복문(게임) 빠져나감

		        if (zombie1.status || zombie2.status) {
		                break;
		        }
				repaint();
				try {
						Thread.sleep(200);
				}catch (InterruptedException e) {
					e.printStackTrace();
				}
			}
		}
		@Override
		public void keyPressed(KeyEvent e) {
			// TODO Auto-generated method stub
			int Keycode = e.getKeyCode();
			

			if(e.getKeyCode()==KeyEvent.VK_UP) { //왼쪽
				hero.jump = true;

			}
			else if(e.getKeyCode()==KeyEvent.VK_RIGHT) { //오른쪽
				hero.moveRight();
				dir =1;
				
			
			}
			else if(e.getKeyCode()==KeyEvent.VK_LEFT) { //왼쪽
				hero.moveLeft();
				dir = 2;

			}

			repaint();

		}
		@Override
		public void keyTyped(KeyEvent e) {
			// TODO Auto-generated method stub
			
		}
		@Override
		public void keyReleased(KeyEvent e) {
			// TODO Auto-generated method stub
			
		}



	}
	public static void main(String [] args) {
		new ZombieGame();
	}
}

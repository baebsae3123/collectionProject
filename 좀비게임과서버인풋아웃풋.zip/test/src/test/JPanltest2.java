package test;

import javax.swing.*;
import java.awt.*;
import java.awt.event.MouseEvent;
import java.awt.event.MouseMotionListener;

public class JPanltest2 extends JFrame{
	private MyPanel panel = new MyPanel();
		public JPanltest2() {
		setTitle("JPanel의 paintComponent() 예제");
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setContentPane(panel);
		setSize(250,220);
		setVisible(true);
		
	}		
		
	class MyPanel extends JPanel implements MouseMotionListener{

		ImageIcon icon = new ImageIcon("img/apple.jpg");		
		Image img = icon.getImage();
		int x =0;
		int y =0;

	    
		public MyPanel() {
			this.addMouseMotionListener(this); //움직이는대로 그려주게 하
			
		}
		
		public void paintComponent(Graphics g) {
			super.paintComponent(g);
			g.setColor(Color.DARK_GRAY);
			g.drawRect(10,10,50,50);  // 50 50 크기
			g.setColor(Color.RED);
			g.drawRect(50,50,50,50); // 50 50 크기
			g.drawString("자바는 재미없다",30,30);
			g.setClip(x,y,100,100);
			g.drawImage(img,x,y,30,30,this);
			}
		
		@Override 
		public void mouseDragged(MouseEvent e) {
			
		}
		@Override
		public void mouseMoved(MouseEvent e) {
			x= e.getX();
			y= e.getY();
			
			
			repaint();
		}

		}
	
	public static void main(String [] args) {
		new JPanltest2();
	}
}

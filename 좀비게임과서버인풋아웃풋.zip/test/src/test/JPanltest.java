package test;

import javax.swing.*;

import test.paintJPanelEx.MyPanel;

import java.awt.*;
import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;

public class JPanltest extends JFrame {
	
	private MyPanel panel = new MyPanel();
	ImageIcon icon = new ImageIcon("img/hero01.png"); //객채를 생성
	ImageIcon zombieicon1 = new ImageIcon("img/enemy1.png");
	ImageIcon zombieicon2 = new ImageIcon("img/enemy2.png");
	ImageIcon backgroundicon = new ImageIcon("img/background.jpg");

	Image img = icon.getImage(); //이미지 를 가져옴
	Image zombie1 = zombieicon1.getImage();
	Image zombie2 = zombieicon2.getImage();
	Image background = backgroundicon.getImage();

	int x =0;
	int y =0;
	int deafult_y = 150;
	int hero_x = 20;

	public JPanltest() {


		setTitle("JPanel의 paintComponent() 예제");
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setContentPane(panel);
		setSize(500,300);
		setVisible(true);
	}

	public void moveRight() {
		hero_x = hero_x + 1;
	}	
	class MyPanel extends JPanel implements KeyListener{ //패널을 자신이 그려줌
		
		@Override 
		public void keyPressed(KeyEvent e) {
			
		}
		@Override 
		public void keyReleased(KeyEvent e) {
			
		}
		
		public void paintComponent(Graphics g) {
			super.paintComponent(g); //부모 그림을 그려줌
			// 실제 패널 그리기
			g.drawImage(background,0,0,getWidth(),getHeight(),this);
		    g.drawImage(img, hero_x, deafult_y, 30, 30, this);
		    g.drawImage(zombie1, 100, deafult_y, 30, 30, this);
		    g.drawImage(zombie2, 200, deafult_y, 30, 30, this);

			
		}
		@Override
		public void keyTyped(KeyEvent e) {
			// TODO Auto-generated method stub
			
		}		
	}
	
	
	public static void main(String[] args) {
		new JPanltest();
	}
}
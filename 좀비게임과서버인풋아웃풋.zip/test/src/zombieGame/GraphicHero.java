package zombieGame;

import java.util.*;
import java.awt.*;
import javax.swing.*;
import javax.swing.ImageIcon;

public class GraphicHero  {
	final int MOVE_STEP = 5;
	final int MAX_X = 500;
	final int MAX_Y = 300;
	
	int x;
	int y;
	int imgWidth =21; //캐릭터 길이
	int imgHeight = 26; //캐릭터 넒이
	int dir; //dir 1이면 오른쪽 0 이면 왼쪽 
	Random r = new Random();
	boolean toggle;  // 초기값은 false
	int count;
	boolean jump ;
	int jumpcount = 1; //점프단계
	
	ImageIcon batImgIcon[] = new ImageIcon[6];
	Image img[] = new Image[6];
	
	public GraphicHero(int x, int y) {
		this.x = x; //받는값 만큼 위치 전하기
		this.y = y;
	
		for(int i=0; i<6; i++) {
			batImgIcon[i] = new ImageIcon("img/hero0"+(i+1)+".png");
			img[i] = batImgIcon[i].getImage();
		}
	}
	public void moveLeft() {
		x = x - MOVE_STEP;
		if(x < 0) x = 0;
		dir= 2;
	}
	
	// �� 
	public void moveRight() {
		x = x + MOVE_STEP;
		if(x > MAX_X - imgWidth) x = MAX_X - imgWidth;
		dir=1;
	}	
	
	
	public boolean heroMove() {
		
		count++;
		if(jump == true) {
			if(jumpcount <= 5) y= y- 10;
			else if(jumpcount <= 10) y= y +10;
			if(jumpcount ==10) {
				jumpcount = 1;
				jump = false;
			}
			else jumpcount++;
				
		}
		if(x > 450) { //목적지 도착
			return true; 
		}
		
		
		if(x >MAX_X -imgWidth) return true;
		else return false;
		
	}
	public void paint(Graphics g) { //점프와 이동 할때 이미지 변함
		if(dir==1) {
			if(jump == true) g.drawImage(img[2] , x, y ,null); //0 1 0 1
			else g.drawImage(img[count%2] , x, y ,null); //0 1 0 1
		}
		else if(dir==2) {
		if(jump == true) g.drawImage(img[5] , x, y ,null); //0 1 0 1
		else if(dir==2) g.drawImage(img[count%2+3], x,y,null); // 4 5  4 5
		}
	}
	public boolean crush(GraphicZombie zombie) {
		//if(zombie.x <x) {}
			
		int cx = x +10;
		int cy = y + 13;
		int zx = zombie.x+10;
		int zy = zombie.y+10;
		double a = Math.pow(cx- zx, 2)+ Math.pow(cy-zy,2);
		double distance = Math.sqrt(a);
		if(distance<(10+10)) return true;
		else return false;
		
	}
}
